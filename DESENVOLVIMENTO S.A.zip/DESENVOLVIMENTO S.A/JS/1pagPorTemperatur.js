

function procurar() {

  const temperaturaFantasma = Number(document.getElementById("fantasmaInput").value);

  if (temperaturaFantasma >= 1 && temperaturaFantasma <= 4) {
    document.getElementById("saidaNomeFantasma").innerHTML = "";
    document.getElementById("saidaCarac").innerHTML = "";
    document.getElementById("saidaFotoFantasma").src = "";
    document.getElementById("saidaComoCombater1").innerHTML = "";
    document.getElementById("saidaComoCombater2").innerHTML = "";
    document.getElementById("saidaComoCombater3").innerHTML = "";
    document.getElementById("saidaComoCombater4").innerHTML = "";
  }

  else if (temperaturaFantasma >= 5 && temperaturaFantasma <= 9) {
    document.getElementById("saidaNomeFantasma").innerHTML = "Senhora Slimer";
    document.getElementById("saidaCarac").innerHTML = "";
    document.getElementById("saidaFotoFantasma").src = "";
    document.getElementById("saidaComoCombater1").innerHTML = "";
    document.getElementById("saidaComoCombater2").innerHTML = "";
    document.getElementById("saidaComoCombater3").innerHTML = "";
    document.getElementById("saidaComoCombater4").innerHTML = "";
  }

  else if (temperaturaFantasma >= 10 && temperaturaFantasma <= 14) {
    document.getElementById("saidaNomeFantasma").innerHTML = "";
    document.getElementById("saidaCarac").innerHTML = "";
    document.getElementById("saidaFotoFantasma").src = "";
    document.getElementById("saidaComoCombater1").innerHTML = "";
    document.getElementById("saidaComoCombater2").innerHTML = "";
    document.getElementById("saidaComoCombater3").innerHTML = "";
    document.getElementById("saidaComoCombater4").innerHTML = "";
  }

  else if (temperaturaFantasma >= 15 && temperaturaFantasma <= 19) {
    document.getElementById("saidaNomeFantasma").innerHTML = "";
    document.getElementById("saidaCarac").innerHTML = "";
    document.getElementById("saidaFotoFantasma").src = "";
    document.getElementById("saidaComoCombater1").innerHTML = "";
    document.getElementById("saidaComoCombater2").innerHTML = "";
    document.getElementById("saidaComoCombater3").innerHTML = "";
    document.getElementById("saidaComoCombater4").innerHTML = "";
  }

  else if (temperaturaFantasma >= 20 && temperaturaFantasma <= 24) {
    document.getElementById("saidaNomeFantasma").innerHTML = "";
    document.getElementById("saidaCarac").innerHTML = "";
    document.getElementById("saidaFotoFantasma").src = "";
    document.getElementById("saidaComoCombater1").innerHTML = "";
    document.getElementById("saidaComoCombater2").innerHTML = "";
    document.getElementById("saidaComoCombater3").innerHTML = "";
    document.getElementById("saidaComoCombater4").innerHTML = "";
  }

  else {
    alert(`${temperaturaFantasma} inexistente`);
  }

  return false


  document.getElementById("fantasmaInput").value = " ";//como limpar inputs?
}
