// const btEsconderDiv = document.getElementById("btEsconderTutorial");
// const escondido = document.getElementById("contEscondido");

// escondido.style.display === "none";

// btEsconderDiv.addEventListener("click", function () {
//     if (escondido.style.display === "block") {
//         escondido.style.display === "none";
//     }
//     else {
//         escondido.style.display === "none";
//     }
// })

