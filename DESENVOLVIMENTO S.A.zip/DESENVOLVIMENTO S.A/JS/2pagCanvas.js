(function () { //funcao para evitar mt uso da memoria ram

}())

var canvas = document.getElementById("telaCanvas"); //puxar o elemento do html
var contexto = canvas.getContext("2d"); //renderizaçao do canvas

var largura = canvas.largura //variavel para armazenar x do canvas
var altura = canvas.altura

//-------area movimentacao-----------------------------//
var esquerda = 65; //37 é o numero da tecla
var cima = 87;
var direita = 68;
var baixo = 83;

//verificando a acao do personagem
var moverEsquerda = moverCima = moverDireita = moverBaixo = false; //movimentação recebe falso pois o personagem comeca parado

//-------area movimentacao-----------------------------//

var tamanhoDoBloco = 32;

var jogador = { //movimentacao o jogador 
    x: tamanhoDoBloco + 2, //o +2 é para cirar uma distancia
    y: tamanhoDoBloco + 2,
    altura: 28,
    largura: 28,
    velocidade: 2

}

var paredes = [];

var labirinto = [ //desenhando o mapa com o num 1, q foi feito na funcao renderizacao.
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 1, 0, 1, 1, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 1, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1],
    [1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1],
    [1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 0, 0, 1, 0, 1, 0, 1, 1],
    [1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 0, 1, 0, 1, 1],
    [1, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 1, 1],
    [1, 1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1],
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]
];

for (let linha in labirinto) { //repeticao para desenhar o labirinto
    for (let coluna in labirinto[linha]) {
        let telha = labirinto[linha][coluna]; //o i é a celula o j é a coluna
        if (telha === 1) { //verificando se o valor do elemento é = a 1
            let parede = {
                x: tamanhoDoBloco * coluna,
                y: tamanhoDoBloco * linha,
                largura: tamanhoDoBloco,
                altura: tamanhoDoBloco
            };
            paredes.push(parede);
        }
    }
}


window.addEventListener("keydown", manipulandoKeydown, false); //evento de quando o usuario tocar nas telcas
window.addEventListener("keyup", manipulandoKeyup, false); //evento de soltar a tecla

//funcao de aperta o botao
function manipulandoKeydown(evento) {
    let key = evento.keyCode; //quardando a informacao da tecla para a variavel key
    switch (key) { //pegando o valor da var key

        case esquerda:
            moverEsquerda = true;
            break; //parando estrutura de alinhamento

        case cima:
            moverCima = true;
            break;

        case direita:
            moverDireita = true;
            break;

        case baixo:
            moverBaixo = true;
            break;
    }
}
//funcao de soltar
function manipulandoKeyup(evento) {
    let key = evento.keyCode;
    switch (key) {

        case esquerda:
            moverEsquerda = false;
            break;

        case cima:
            moverCima = false;
            break;

        case direita:
            moverDireita = false;
            break;

        case baixo:
            moverBaixo = false;
            break;
    }
}


function bloqueioParede(objetoA, objetoB) {
    let distanciaX = (objetoA.x + objetoA.largura / 2) - (objetoB.x + objetoB.largura / 2);
    let distanciaY = (objetoA.y + objetoA.altura / 2) - (objetoB.y + objetoB.altura / 2)

    let somaLargura = (objetoA.largura + objetoB.largura) / 2;
    let somaAltura = (objetoA.altura + objetoB.altura) / 2;

    if (Math.abs(distanciaX) < somaLargura && Math.abs(distanciaY) < somaAltura) {
        let sobrepisicaoX = somaLargura - Math.abs(distanciaX);
        let sobrepisicaoY = somaAltura - Math.abs(distanciaY);

        if (sobrepisicaoX > sobrepisicaoY) {
            objetoA.y = distanciaY > 0 ? objetoA.y + sobrepisicaoY : objetoA.y - sobrepisicaoY;
        } else {
            objetoA.x = distanciaY > 0 ? objetoA.x + sobrepisicaox : objetoA.y - sobrepisicaox;
        }
    }
}



function atualizacao() {//verificando estado das variaveis 




    if (moverEsquerda && !moverDireita) { //condicional boliana
        jogador.x -= jogador.velocidade; //atribuindo a velocidade no eixo x
    } else if (moverDireita && !moverEsquerda) {
        jogador.x += jogador.velocidade;
    }

    if (moverCima && !moverBaixo) {
        jogador.y -= jogador.velocidade;
    } else if (moverBaixo && !moverCima) {
        jogador.y += jogador.velocidade;
    }

    for (let i in paredes) {
        let parede = paredes[i];
        bloqueioParede(jogador, parede);
    }
}




function renderizacao() {//mostra os desenhos na tela
    contexto.clearRect(0, 0, largura, altura); //limapando a tela para nao ficar
    contexto.save(); //salvando o estado da variavel 
    for (let linha in labirinto) { //repeticao para desenhar o labirinto
        for (let coluna in labirinto[linha]) {
            let telha = labirinto[linha][coluna]; //o i é a celula o j é a coluna
            if (telha === 1) { //verificando se o valor do elemento é = a 1
                var x = coluna * tamanhoDoBloco; //alinhando o eixo X
                var y = linha * tamanhoDoBloco; //o tamanhoDoBloco é o tamanho da coluna dos blocos
                contexto.fillRect(x, y, tamanhoDoBloco, tamanhoDoBloco)
            }
        }
    }

    contexto.fillStyle = "#00f"; //cor do personagem
    contexto.fillRect(jogador.x, jogador.y, jogador.largura, jogador.altura);

    contexto.restore(); //restalrando a info da variavel


}

function repeticao() {
    atualizacao();
    renderizacao();
    requestAnimationFrame(repeticao, canvas);
}
requestAnimationFrame(repeticao, canvas) // chamar a si propria para att a tela




